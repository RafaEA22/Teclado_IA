import cv2
import mediapipe as mp
import time
import pygame
import pickle
from collections import defaultdict

# Inicializar pygame para sonido
pygame.init()
click_sound = pygame.mixer.Sound("click.wav")

# Cargar modelo de predicción de trigramas
with open("modelo_trigramas.pkl", "rb") as f:
    modelo_trigramas = pickle.load(f)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.7)

# Crear teclado completo
filas = [
    list("QWERTYUIOP"),
    list("ASDFGHJKL"),
    list("ZXCVBNM"),
    ["ESPACIO", "BORRAR"] + [str(i) for i in range(10)]
]
tecla_size = 80
texto_escrito = ""
ultima_tecla = None
tiempo_inicio = 0

# Variables para predecir y mostrar sugerencia
sugerencia = ""
mostrar_sugerencia = False

# Detección de palma abierta para borrar texto
def detectar_gesto_palma_abierta(landmarks):
    dedos_abiertos = [
        landmarks.landmark[8].y < landmarks.landmark[6].y,
        landmarks.landmark[12].y < landmarks.landmark[10].y,
        landmarks.landmark[16].y < landmarks.landmark[14].y,
        landmarks.landmark[20].y < landmarks.landmark[18].y
    ]
    pulgar_izq = landmarks.landmark[4].x < landmarks.landmark[3].x
    pulgar_der = landmarks.landmark[4].x > landmarks.landmark[3].x
    return all(dedos_abiertos) and (pulgar_izq or pulgar_der)

def detectar_punta_indice(hand_landmarks, width, height):
    x = int(hand_landmarks.landmark[8].x * width)
    y = int(hand_landmarks.landmark[8].y * height)
    return x, y

def predecir_palabra(texto, modelo):
    palabras = texto.strip().split()
    if not palabras:
        return ""
    prefijo = palabras[-1].lower()
    opciones = set()
    for clave, siguientes in modelo.items():
        for palabra, _ in siguientes.items():
            if palabra.startswith(prefijo):
                opciones.add(palabra)
    return sorted(opciones)[:3]

cap = cv2.VideoCapture(0)
cv2.namedWindow("Teclado Mano Predictivo", cv2.WND_PROP_FULLSCREEN)
cv2.setWindowProperty("Teclado Mano Predictivo", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.flip(frame, 1)
    frame = cv2.resize(frame, (1920, 1080))
    height, width, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    resultado = hands.process(rgb)

    # Dibujar teclado
    teclas_pos = []
    teclado_ancho = max(len(fila) for fila in filas) * (tecla_size + 10)
    y_base = height - (len(filas) * (tecla_size + 10)) - 100

    for fila_idx, fila in enumerate(filas):
        fila_ancho = len(fila) * (tecla_size + 10)
        x_base = (width - fila_ancho) // 2
        for col_idx, tecla in enumerate(fila):
            x = x_base + col_idx * (tecla_size + 10)
            y = y_base + fila_idx * (tecla_size + 10)
            teclas_pos.append((tecla, (x, y)))
            cv2.rectangle(frame, (x, y), (x + tecla_size, y + tecla_size), (50, 50, 50), -1)
            cv2.rectangle(frame, (x, y), (x + tecla_size, y + tecla_size), (100, 100, 100), 2)
            texto_tecla = " " if tecla == "ESPACIO" else tecla
            text_size = cv2.getTextSize(texto_tecla, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
            text_x = x + (tecla_size - text_size[0]) // 2
            text_y = y + (tecla_size + text_size[1]) // 2
            cv2.putText(frame, texto_tecla, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    if resultado.multi_hand_landmarks:
        for hand_landmarks in resultado.multi_hand_landmarks:
            x, y = detectar_punta_indice(hand_landmarks, width, height)
            cv2.circle(frame, (x, y), 12, (0, 0, 255), -1)

            if detectar_gesto_palma_abierta(hand_landmarks):
                texto_escrito = ""
                sugerencia = ""

            for tecla, (tx, ty) in teclas_pos:
                if tx < x < tx + tecla_size and ty < y < ty + tecla_size:
                    if ultima_tecla != tecla:
                        ultima_tecla = tecla
                        tiempo_inicio = time.time()
                    elif time.time() - tiempo_inicio > 1:
                        if tecla == "ESPACIO":
                            texto_escrito += " "
                        elif tecla == "BORRAR":
                            texto_escrito = texto_escrito[:-1]
                        else:
                            texto_escrito += tecla
                        click_sound.play()
                        ultima_tecla = None

            # Sugerencia seleccionable
            if sugerencia:
                for idx, sug in enumerate(sugerencia):
                    sx = 50
                    sy = 470 + idx * 40
                    cv2.rectangle(frame, (sx, sy), (sx + 200, sy + 35), (255, 255, 200), -1)
                    cv2.putText(frame, sug, (sx + 5, sy + 25), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2)
                    if sx < x < sx + 200 and sy < y < sy + 35:
                        if ultima_tecla != f"SUG{idx}":
                            ultima_tecla = f"SUG{idx}"
                            tiempo_inicio = time.time()
                        elif time.time() - tiempo_inicio > 1:
                            palabras = texto_escrito.strip().split()
                            if palabras:
                                palabras[-1] = sug
                                texto_escrito = " ".join(palabras) + " "
                                click_sound.play()
                                sugerencia = ""
                                ultima_tecla = None

    sugerencia = predecir_palabra(texto_escrito, modelo_trigramas)
    texto_central = texto_escrito.strip()
    texto_pos_x = width // 2 - len(texto_central) * 10
    cv2.putText(frame, texto_central, (texto_pos_x, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 2)

    cv2.imshow("Teclado Mano Predictivo", frame)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
